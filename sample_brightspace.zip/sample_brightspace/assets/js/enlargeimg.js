$(function() {
  enlargeImg();
})
//查看大图
function enlargeImg() {
  $(".enlargeImg").click(function() {
    $(this).after("<div onclick='closeImg()' class='enlargeImg_wrapper'></div>");
    var imgSrc = $(this).attr('src');
    $(".enlargeImg_wrapper").css("background-image", "url(" + imgSrc + ")");
    $('.enlargeImg_wrapper').fadeIn(200);
  })
}
//关闭并移除图层
function closeImg() {
  $('.enlargeImg_wrapper').fadeOut(200).remove();
}